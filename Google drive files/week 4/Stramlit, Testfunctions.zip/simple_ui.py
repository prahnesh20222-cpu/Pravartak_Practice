import httpx
import streamlit as st


endpoint = 'http://0.0.0.0:8000/chat'
prams = {}


message_input = st.text_input("Enter your Message : ")
temprature = st.text_input("Enter Required Temprature : ")
retries = st.text_input("Enter Retries : ")



if st.button("Query the Server!"):

    body = {
        "query": message_input,
        "temp": float(temprature),
        "retries": int(retries)
        }
    try:
        with httpx.Client() as client:
            response = client.post(endpoint, params=prams, json=body, timeout=120)
            st.write(response.json())
    except Exception as e:
        print(f"An error occured {e}")

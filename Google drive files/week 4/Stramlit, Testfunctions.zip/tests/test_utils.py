import pytest
import sys, os
import respx
import httpx
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils import calculate_interest, fetch_stock_data, call_open_ai

@pytest.mark.asyncio
async def test_calculate_simple_interest_basic():
    result = await calculate_interest(5000, 6.5, 2.5)
    assert result == {"interest": 812.5, "total_amount": 5812.5} # Expected Output

@pytest.mark.asyncio
async def test_calculate_simple_interest_rate_zero():
    result = await calculate_interest(1000, 0.0, 5)
    assert result == {"interest": 0.0, "total_amount": 1000.0}

@pytest.mark.asyncio
@respx.mock
async def test_fetch_stock_data():
    respx.get("https://www.alphavantage.co/query").mock(
        return_value=httpx.Response(200, json={"Time Series (5min)": {"09:30:00": {"1. open": "150.0"}}})
    )
    result = await fetch_stock_data("AAPL")
    assert 'Time Series (5min)' in result

@pytest.mark.asyncio
async def test_call_open_ai():
    # Setting LLM Respose
    mock_response = MagicMock()
    mock_response.choices[0].message.content = "Hello"
    mock_response.model = 'gpt 4'
    mock_response.usage.prompt_tokens = 10
    mock_response.usage.completion_tokens = 5
    mock_response.usage.total_tokens = 15

    with patch('utils.client.chat.completions.create', new=AsyncMock(return_value=mock_response)):
        result = await call_open_ai("Hi")
        # Testing Function response
        assert result["response"] == "Hello"
        assert result["model"] == 'gpt 4'
        assert result["prompt_tokens"] == 10

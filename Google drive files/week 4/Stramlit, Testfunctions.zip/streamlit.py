import streamlit as st

st.title("My frist Website in python")

user_name = st.text_input("Enter your name : ")

if user_name:
    st.write(f"Welcome {user_name}")

age = st.slider("Select your age : ", 0, 100, 25)
st.write(f"your age is {age}")

if st.button("Click me!"):
    st.success("You clicked me..!")
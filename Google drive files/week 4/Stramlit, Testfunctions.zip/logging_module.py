import logging
import json
from datetime import datetime

class CustomJsonFormater(logging.Formatter):
    def format(self, record):
        log_rec = {
            "timestamp" : datetime.fromtimestamp(record.created).strftime('%Y-%m-%dT%H:%M:%S'),
            "level" : record.levelname,
            "message" : record.getMessage()
        }
        return json.dumps(log_rec)

def setup_logger(name = "Mylooger", level=logging.INFO):
    logger = logging.getLogger(name)
    logger.setLevel(level)
    handler = logging.StreamHandler()
    handler.setFormatter(CustomJsonFormater())
    logger.addHandler(handler)
    return logger

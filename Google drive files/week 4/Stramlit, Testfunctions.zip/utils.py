from openai import AsyncOpenAI
from settings import my_settings
import asyncio
import time
import httpx

client = AsyncOpenAI(
    api_key=my_settings.OPEN_AI_API_KEY,
    base_url=my_settings.OPEN_AI_BASE_URL
)

async def call_open_ai(user_query : str, 
                       temperature : float = 0.2, 
                       retries : int = my_settings.OPEN_AI_RETRIES) -> dict:
    for attempt in range(retries): # 0,1,2
        try:
            start_time = time.perf_counter()
            response = await client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant. respond to the user as per the question in a gentle way"},
                {"role": "user", "content": user_query}
            ],
            temperature=temperature,
            timeout=60
            )
            end_time = time.perf_counter()
            final_reponse = {
            "response": response.choices[0].message.content,
            "model": response.model,
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens,
            "time_taken" : end_time-start_time
            }
            return final_reponse
        except Exception as e:
            end_time = time.perf_counter()
            time_taken = end_time-start_time
            print(time_taken)
            if attempt == retries - 1:
                raise e
            waitime = attempt + 1 * 2  # 2 sec, 4 sec, 6 sec
            await asyncio.sleep(waitime)

async def calculate_interest(principal: float, rate: float, time:float) -> dict:
    interest = (principal * rate * time) / 100
    total_repayable = principal + interest
    return {
        "interest" : round(interest,2),
        "total_amount" : round(total_repayable,2)
    }

async def fetch_stock_data(symbol: str, interval:str = "5min", apikey:str = 'demo') -> dict:
    url = "https://www.alphavantage.co/query"
    params = {
      "function": "TIME_SERIES_INTRADAY",
      "symbol": symbol,
      "interval": interval,
      "apikey": apikey,
  }
    response = httpx.get(url, params=params, timeout=30)
    return response.json()
